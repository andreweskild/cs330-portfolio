﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"

#include <iostream>

#include "cylinder.h"
#include "cube.h"
#include "plane.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
bool UCreateTexture(const char* filename, GLuint& textureId);
void processInput(GLFWwindow* window);

// settings
const unsigned int SCR_WIDTH = 600;
const unsigned int SCR_HEIGHT = 900;

// camera
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 20.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float cameraBaseSpeed = 2.5;

bool isOrtho = false;
bool firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0 / 2.0;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;


// Texture Id
GLuint doorTextureId;
GLuint doorSpecTextureId;
GLuint stoveTextureId;
GLuint stoveSpecTextureId;
GLuint stovePipeTextureId;
GLuint stovePipeSpecTextureId;
GLuint floorTextureId;
GLuint floorSpecTextureId;
GLuint logEndTextureId;
GLuint logEndSpecTextureId;
GLuint wallTextureId;
GLuint wallSpecTextureId;
GLuint pillarTextureId;
GLuint pillarSpecTextureId;

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Fireplace", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader ourShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");

	const char* doorTexFilename = "./textures/stove-door.jpg";
	if (!UCreateTexture(doorTexFilename, doorTextureId)) {
		std::cout << "Failed to load texture " << doorTexFilename << std::endl;
		return EXIT_FAILURE;
	}
	
	const char* doorSpecFilename = "./textures/stove-door-specular.jpg";
	if (!UCreateTexture(doorSpecFilename, doorSpecTextureId)) {
		std::cout << "Failed to load texture " << doorSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* stoveTexFilename = "./textures/stove-metal.jpg";
	if (!UCreateTexture(stoveTexFilename, stoveTextureId)) {
		std::cout << "Failed to load texture " << stoveTexFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* stoveSpecFilename = "./textures/stove-metal-specular.jpg";
	if (!UCreateTexture(stoveSpecFilename, stoveSpecTextureId)) {
		std::cout << "Failed to load texture " << stoveSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* stovePipeTexFilename = "./textures/stove-pipe.jpg";
	if (!UCreateTexture(stovePipeTexFilename, stovePipeTextureId)) {
		std::cout << "Failed to load texture " << stovePipeTexFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* stovePipeSpecFilename = "./textures/stove-pipe-specular.jpg";
	if (!UCreateTexture(stovePipeSpecFilename, stovePipeSpecTextureId)) {
		std::cout << "Failed to load texture " << stovePipeSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* floorFilename = "./textures/floor-hide.jpg";
	if (!UCreateTexture(floorFilename, floorTextureId)) {
		std::cout << "Failed to load texture " << floorFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* floorSpecFilename = "./textures/floor-hide-specular.jpg";
	if (!UCreateTexture(floorSpecFilename, floorSpecTextureId)) {
		std::cout << "Failed to load texture " << floorSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* logFilename = "./textures/log-end.jpg";
	if (!UCreateTexture(logFilename, logEndTextureId)) {
		std::cout << "Failed to load texture " << logFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* logSpecFilename = "./textures/log-end-specular.jpg";
	if (!UCreateTexture(logSpecFilename, logEndSpecTextureId)) {
		std::cout << "Failed to load texture " << logSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* wallFilename = "./textures/tile.jpg";
	if (!UCreateTexture(wallFilename, wallTextureId)) {
		std::cout << "Failed to load texture " << wallFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* wallSpecFilename = "./textures/tile-specular.jpg";
	if (!UCreateTexture(wallSpecFilename, wallSpecTextureId)) {
		std::cout << "Failed to load texture " << wallSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* pillarFilename = "./textures/pillar.jpg";
	if (!UCreateTexture(pillarFilename, pillarTextureId)) {
		std::cout << "Failed to load texture " << pillarFilename << std::endl;
		return EXIT_FAILURE;
	}

	const char* pillarSpecFilename = "./textures/tile-specular.jpg";
	if (!UCreateTexture(pillarSpecFilename, pillarSpecTextureId)) {
		std::cout << "Failed to load texture " << pillarSpecFilename << std::endl;
		return EXIT_FAILURE;
	}

	// Tell OpenGL which texture unit each sampler belongs to
	ourShader.use();
	// Set texture as texture unit 0
	ourShader.setInt("material.diffuse", 0);
	ourShader.setInt("material.specular", 1);

	// positions of the point lights
	glm::vec3 pointLightPositions[] = {
		glm::vec3(1.7f,  0.5f,  -2.0f),
		glm::vec3(2.3f, -3.3f, -4.0f),
		glm::vec3(-4.0f,  2.0f, -12.0f),
		glm::vec3(0.0f,  0.0f, -3.0f)
	};

	static_meshes_3D::Cylinder stovePipe(0.75f, 10, 10, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, stovePipeTextureId, stovePipeSpecTextureId);
	static_meshes_3D::Cube stoveBox(true, true, true);
	static_meshes_3D::Cube stoveDoor(true, true, true);
	static_meshes_3D::Cube stoveDoorHandle(true, true, true);
	static_meshes_3D::Cube stoveLogBoxLeft(true, true, true);
	static_meshes_3D::Cube stoveLogBoxRight(true, true, true);
	static_meshes_3D::Cube stoveLogBoxBack(true, true, true);
	static_meshes_3D::Plane floorPlane(true, true, true);
	static_meshes_3D::Plane wallPlane(true, true, true);
	static_meshes_3D::Cylinder log1(0.25f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log2(0.4f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log3(0.3f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log4(0.2f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log5(0.3f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log6(0.2f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log7(0.3f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log8(0.4f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log9(0.3f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cylinder log10(0.2f, 10, 4, glm::vec4(1.0f, 0.0f, 0.0f, 1.0f), true, true, logEndTextureId, logEndSpecTextureId);
	static_meshes_3D::Cube pillarRight(true, true, true);
	static_meshes_3D::Cube pillarLeft(true, true, true);



	glm::mat4 model;
	float angle;

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// activate shader
		ourShader.use();
		ourShader.setVec3("viewPos", cameraPos.x, cameraPos.y, cameraPos.z);

		// directional light
		ourShader.setVec3("dirLight.direction", -0.8f, -0.7f, -0.8f);
		ourShader.setVec3("dirLight.ambient", 0.3f, 0.3f, 0.3f);
		ourShader.setVec3("dirLight.diffuse", 1.0f, 1.0f, 1.0f);
		ourShader.setVec3("dirLight.specular", 1.0f, 1.0f, 1.0f);
		// point light 1
		ourShader.setVec3("pointLights[0].position", pointLightPositions[0]);
		ourShader.setVec3("pointLights[0].ambient", 0.5f, 0.5f, 0.5f);
		ourShader.setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
		ourShader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
		ourShader.setFloat("pointLights[0].constant", 1.0f);
		ourShader.setFloat("pointLights[0].linear", 0.09);
		ourShader.setFloat("pointLights[0].quadratic", 0.032);
		// point light 2
		ourShader.setVec3("pointLights[1].position", pointLightPositions[1]);
		ourShader.setVec3("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
		ourShader.setVec3("pointLights[1].diffuse", 0.8f, 0.8f, 0.8f);
		ourShader.setVec3("pointLights[1].specular", 1.0f, 1.0f, 1.0f);
		ourShader.setFloat("pointLights[1].constant", 1.0f);
		ourShader.setFloat("pointLights[1].linear", 0.09);
		ourShader.setFloat("pointLights[1].quadratic", 0.032);
		// point light 3
		ourShader.setVec3("pointLights[2].position", pointLightPositions[2]);
		ourShader.setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
		ourShader.setVec3("pointLights[2].diffuse", 0.8f, 0.8f, 0.8f);
		ourShader.setVec3("pointLights[2].specular", 1.0f, 1.0f, 1.0f);
		ourShader.setFloat("pointLights[2].constant", 1.0f);
		ourShader.setFloat("pointLights[2].linear", 0.09);
		ourShader.setFloat("pointLights[2].quadratic", 0.032);
		// point light 4
		ourShader.setVec3("pointLights[3].position", pointLightPositions[3]);
		ourShader.setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
		ourShader.setVec3("pointLights[3].diffuse", 0.8f, 0.8f, 0.8f);
		ourShader.setVec3("pointLights[3].specular", 1.0f, 1.0f, 1.0f);
		ourShader.setFloat("pointLights[3].constant", 1.0f);
		ourShader.setFloat("pointLights[3].linear", 0.09);
		ourShader.setFloat("pointLights[3].quadratic", 0.032);

		// material properties
		ourShader.setFloat("material.shininess", 32.0f);

		if (isOrtho) {
			// pass orthographic projection matrix to shader
			float orthoScale = 100.0f;
			glm::mat4 projection = glm::ortho(-(SCR_WIDTH / orthoScale), SCR_WIDTH / orthoScale, -(SCR_HEIGHT / orthoScale), SCR_HEIGHT / orthoScale, -10.0f, 100.0f);
			ourShader.setMat4("projection", projection);
		}
		else {
			// pass perspective matrix to shader
			glm::mat4 projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
			ourShader.setMat4("projection", projection);
		}


		// camera/view transformation
		glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
		ourShader.setMat4("view", view);

		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		model = glm::mat4(1.0f);
		model = glm::scale(model, glm::vec3(3.6f, 2.6f, 4.25f));
		ourShader.setMat4("model", model);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, doorTextureId);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, doorSpecTextureId);

		stoveDoor.render();


		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, 5.0f, 0.0f));
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		ourShader.setMat4("model", model);

		stovePipe.render();

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, stoveTextureId);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, stoveSpecTextureId);

		model = glm::mat4(1.0f);
		model = glm::scale(model, glm::vec3(4.0f, 3.0f, 4.0f));
		ourShader.setMat4("model", model);

		stoveBox.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(2.0f, 0.0f, 2.5f));
		model = glm::rotate(model, glm::radians(-100.0f), glm::vec3(-0.2f, 0.0f, 1.0f));
		model = glm::scale(model, glm::vec3(0.2f, 0.8f, 0.2f));
		ourShader.setMat4("model", model);

		stoveDoorHandle.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-1.75f, -3.0f, 0.0f));
		model = glm::scale(model, glm::vec3(0.5f, 3.0f, 4.0f));
		ourShader.setMat4("model", model);

		stoveLogBoxLeft.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(1.75f, -3.0f, 0.0f));
		model = glm::scale(model, glm::vec3(0.5f, 3.0f, 4.0f));
		ourShader.setMat4("model", model);

		stoveLogBoxRight.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, -3.0f, -1.75f));
		model = glm::scale(model, glm::vec3(3.0f, 3.0f, 0.5f));
		ourShader.setMat4("model", model);

		stoveLogBoxBack.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-1.25f, -4.25f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log1.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(1.15f, -4.1f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log2.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-0.7f, -4.25f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log3.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-0.2f, -4.3f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log4.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.5f, -4.2f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log5.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-1.25f, -3.75f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log6.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.8f, -3.5f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log7.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-0.7f, -3.55f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log8.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-0.1f, -3.8f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log9.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.35f, -3.7f, 0.0f));
		model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		ourShader.setMat4("model", model);

		log10.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, -4.5f, 0.0f));
		model = glm::scale(model, glm::vec3(10.0f, 0.0f, 10.0f));
		ourShader.setMat4("model", model);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, floorTextureId);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, floorSpecTextureId);

		floorPlane.render();

		model = glm::mat4(1.0f);
		model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::translate(model, glm::vec3(0.0f, 2.5f, 3.0f));
		model = glm::scale(model, glm::vec3(8.0f, 0.0f, 8.0f));
		ourShader.setMat4("model", model);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, wallTextureId);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, wallSpecTextureId);

		wallPlane.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-5.0f, 0.0f, -2.0f));
		model = glm::scale(model, glm::vec3(2.0f, 20.0f, 2.0f));
		ourShader.setMat4("model", model);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, pillarTextureId);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, pillarSpecTextureId);

		pillarLeft.render();

		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(5.0f, 0.0f, -2.0f));
		model = glm::scale(model, glm::vec3(2.0f, 20.0f, 2.0f));
		ourShader.setMat4("model", model);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, pillarTextureId);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, pillarSpecTextureId);

		pillarRight.render();

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}


	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}


bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// Set the texture wrapping parameters.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// Set texture filtering parameters.
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << channels << " channels" << std::endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		//glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture.

		return true;
	}

	// Error loading the image
	return false;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraSpeed = cameraBaseSpeed * deltaTime;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		cameraPos += cameraUp * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		cameraPos -= cameraUp * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
		isOrtho = !isOrtho;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	float sensitivity = 0.1f; // change this value to your liking
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// make sure that when pitch is out of bounds, screen doesn't get flipped
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	// adjusts the movement speed of the camera when the mouse wheel is scrolled
	// we check that movement speed is at least zero because if the speed is set to 
	// a negative number, the camera will go backwards
	float newBaseSpeed = cameraBaseSpeed - (float)yoffset;
	if (newBaseSpeed >= 0) {
		cameraBaseSpeed = newBaseSpeed;
	}
}