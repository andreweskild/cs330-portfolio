// GLM
#include <glm/glm.hpp>

// Project
#include "plane.h"

namespace static_meshes_3D {

    glm::vec3 Plane::vertices[6] =
    {
        // Bottom face
        glm::vec3(-1.0f, 0.0f, 1.0f), glm::vec3(1.0f, 0.0f, 1.0f), glm::vec3(1.0f, 0.0f, -1.0f), glm::vec3(1.0f, 0.0f, -1.0f), glm::vec3(-1.0f, 0.0f, -1.0f), glm::vec3(-1.0f, 0.0f, 1.0f),
    };

    glm::vec2 Plane::textureCoordinates[6] =
    {
        glm::vec2(0.0f, 1.0f), glm::vec2(1.0f, 1.0f), glm::vec2(1.0f, 0.0f),
        glm::vec2(1.0f, 0.0f), glm::vec2(0.0f, 0.0f), glm::vec2(0.0f, 1.0f)
    };

    glm::vec3 Plane::normals[1] =
    {
        glm::vec3(0.0f, 1.0f, 0.0f), // Top face
    };

    Plane::Plane(bool withPositions, bool withTextureCoordinates, bool withNormals)
        : StaticMesh3D(withPositions, withTextureCoordinates, withNormals)
    {
        initializeData();
    }


    void Plane::render() const
    {
        if (!_isInitialized) {
            return;
        }

        glBindVertexArray(_vao);
        glDrawArrays(GL_TRIANGLES, 0, 6);
    }

    void Plane::initializeData()
    {
        if (_isInitialized) {
            return;
        }

        glGenVertexArrays(1, &_vao);
        glBindVertexArray(_vao);

        const auto numVertices = 6;
        const auto vertexByteSize = getVertexByteSize();
        _vbo.createVBO(vertexByteSize * numVertices);
        _vbo.bindVBO();

        if (hasPositions())
        {
            _vbo.addRawData(vertices, sizeof(glm::vec3) * numVertices);
        }

        if (hasTextureCoordinates())
        {
            _vbo.addRawData(textureCoordinates, sizeof(glm::vec2) * 6);
        }
        if (hasNormals())
        {
            _vbo.addRawData(&normals[0], sizeof(glm::vec3), 6);
        }

        _vbo.uploadDataToGPU(GL_STATIC_DRAW);
        setVertexAttributesPointers(numVertices);
        _isInitialized = true;
    }

} // namespace static_meshes_3D